#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ]; then echo "需要管理员权限，请使用提供的一键命令运行。"; exit 1; fi
if ! command -v curl >/dev/null 2>&1 || ! command -v openssl >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get install -y curl ca-certificates openssl;
  elif command -v dnf >/dev/null 2>&1; then dnf install -y curl ca-certificates openssl;
  elif command -v yum >/dev/null 2>&1; then yum install -y curl ca-certificates openssl;
  else echo "系统缺少curl/openssl且无法识别包管理器。"; exit 1; fi
fi
if ! command -v docker >/dev/null 2>&1; then
  echo "[1/7] 自动安装Docker……"; curl -fsSL https://get.docker.com | sh; systemctl enable --now docker
else echo "[1/7] Docker已存在。"; fi
docker compose version >/dev/null 2>&1 || { echo "Docker Compose不可用，请更新Docker。"; exit 1; }
if [ ! -f .env ]; then
  echo "[2/7] 配置域名。"
  read -rp "请输入已经解析到本VPS的域名（例如 library.example.com）: " domain
  domain="${domain#http://}"; domain="${domain#https://}"; domain="${domain%%/*}"
  [[ "$domain" =~ ^[A-Za-z0-9.-]+$ ]] || { echo "域名格式不正确。"; exit 1; }
  password="$(openssl rand -hex 10)"; secret="$(openssl rand -hex 32)"; umask 077
  printf 'DOMAIN=%s\nADMIN_PASSWORD=%s\nSESSION_SECRET=%s\n' "$domain" "$password" "$secret" > .env
else
  domain="$(sed -n 's/^DOMAIN=//p' .env)"; password="$(sed -n 's/^ADMIN_PASSWORD=//p' .env)"
  echo "[2/7] 沿用现有域名和数据。"
fi
[ -n "$domain" ] && [ -n "$password" ] || { echo ".env配置不完整。"; exit 1; }
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q '^Status: active'; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi
echo "[3/7] 构建并启动网站……"; docker compose up -d --build
echo "[4/7] 等待应用健康检查……"; status=""
for _ in $(seq 1 90); do status="$(docker inspect --format '{{.State.Health.Status}}' "$(docker compose ps -q app)" 2>/dev/null || true)"; [ "$status" = healthy ] && break; sleep 2; done
[ "$status" = healthy ] || { docker compose logs --tail=150; echo "应用启动失败。"; exit 1; }
echo "[5/7] 执行真实登录、添加、自动封面下载、图片读取、删除测试……"
docker compose exec -T app node --input-type=module - <<'JS'
const base='http://127.0.0.1:3000';
const login=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:process.env.ADMIN_PASSWORD})});
if(!login.ok)throw new Error('登录自检失败');const cookie=login.headers.get('set-cookie').split(';')[0];
const headers={'Content-Type':'application/json','Cookie':cookie};
const created=await fetch(base+'/api/items',{method:'POST',headers,body:JSON.stringify({title:'Attack on Titan',description:'deployment self test',status:'active'})});
if(!created.ok)throw new Error('添加自检失败 '+await created.text());const item=await created.json();
if(!item.cover)throw new Error('所有在线封面来源均未返回图片，请检查VPS网络');
const image=await fetch(base+item.cover,{headers:{Cookie:cookie}});if(!image.ok||!(image.headers.get('content-type')||'').startsWith('image/'))throw new Error('封面缓存读取失败');
const removed=await fetch(base+'/api/items/'+item.id,{method:'DELETE',headers});if(!removed.ok)throw new Error('删除自检失败');
console.log('应用全流程与真实封面下载：PASS');
JS
echo "[6/7] 等待域名HTTPS上线……"; online=""
for _ in $(seq 1 60); do if curl -fsS --max-time 10 "https://$domain/api/health" >/dev/null 2>&1; then online=yes; break; fi; sleep 3; done
[ "$online" = yes ] || { docker compose logs --tail=150 caddy; echo "HTTPS未上线。请确认域名A记录指向本VPS，且80/443端口未被其他程序占用。"; exit 1; }
echo "[7/7] 所有验证通过。"
printf '\n========================================\n网站：https://%s\n管理员密码：%s\n========================================\n请保存密码。它也保存在：%s/.env\n' "$domain" "$password" "$PWD"
