#!/usr/bin/env python3
import base64, hashlib, hmac, http.cookies, http.server, json, os, pathlib, re, secrets, shutil, tempfile, threading, time, urllib.parse, urllib.request, uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
ROOT=pathlib.Path(__file__).resolve().parent; PUBLIC=ROOT/'public'; DATA=pathlib.Path(os.environ.get('DATA_DIR','/var/lib/personal-media-library')); COVERS=DATA/'covers'; PORT=int(os.environ.get('PORT','8080')); HOST=os.environ.get('HOST','0.0.0.0'); SECRET=os.environ.get('SESSION_SECRET') or secrets.token_hex(32); SECURE=os.environ.get('COOKIE_SECURE','false').lower()=='true'; UA='PersonalMediaLibrary/3.0'
DATA.mkdir(parents=True,exist_ok=True);COVERS.mkdir(exist_ok=True);LIB=DATA/'library.json';SETTINGS=DATA/'settings.json';LOCK=threading.RLock();ATTEMPTS={}
def atomic(path,obj):
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8');os.chmod(tmp,0o600);tmp.replace(path)
def loadlib():
 try:
  d=json.loads(LIB.read_text('utf-8'));assert isinstance(d.get('items'),list);return d
 except FileNotFoundError:d={'version':3,'items':[]};atomic(LIB,d);return d
DB=loadlib()
def save():
 with LOCK:
  if LIB.exists():shutil.copy2(LIB,DATA/'library.backup.json')
  atomic(LIB,DB)
def pw_hash(p,salt=None):
 salt=salt or secrets.token_bytes(16);return salt.hex()+':'+hashlib.scrypt(p.encode(),salt=salt,n=16384,r=8,p=1).hex()
def init_settings():
 if SETTINGS.exists():return json.loads(SETTINGS.read_text('utf-8'))['passwordHash']
 p=os.environ.get('ADMIN_PASSWORD','');
 if len(p)<10:raise RuntimeError('ADMIN_PASSWORD必须至少10位')
 h=pw_hash(p);atomic(SETTINGS,{'passwordHash':h});return h
PASSWORD_HASH=init_settings()
def check_pw(p):
 try:s,h=PASSWORD_HASH.split(':');return hmac.compare_digest(pw_hash(p,bytes.fromhex(s)).split(':')[1],h)
 except:return False
def token():
 body=base64.urlsafe_b64encode(json.dumps({'exp':int(time.time())+2592000}).encode()).rstrip(b'=');sig=hmac.new(SECRET.encode(),body,hashlib.sha256).digest();return body.decode()+'.'+base64.urlsafe_b64encode(sig).rstrip(b'=').decode()
def verify(t):
 try:
  b,s=t.split('.');pad=lambda x:x+'='*(-len(x)%4);sig=base64.urlsafe_b64decode(pad(s));assert hmac.compare_digest(sig,hmac.new(SECRET.encode(),b.encode(),hashlib.sha256).digest());return json.loads(base64.urlsafe_b64decode(pad(b)))['exp']>time.time()
 except:return False
def norm(s):return ''.join(c for c in s.casefold() if c.isalnum())
def score(q,t):
 q,t=norm(q),norm(t)
 if not q or not t:return 0
 if q==t:return 100
 if q in t or t in q:return 70-abs(len(q)-len(t))
 return len(set(q)&set(t))/max(1,len(set(q)))*30
def getjson(url,data=None):
 req=urllib.request.Request(url,data=data,headers={'User-Agent':UA,'Content-Type':'application/json'});return json.loads(urllib.request.urlopen(req,timeout=9).read())
def wiki(title,lang):
 q=urllib.parse.urlencode({'action':'query','format':'json','generator':'search','gsrsearch':title,'gsrlimit':8,'prop':'pageimages|info','inprop':'url','piprop':'thumbnail','pithumbsize':800});d=getjson(f'https://{lang}.wikipedia.org/w/api.php?{q}');return [{'title':p['title'],'image':p['thumbnail']['source'],'page':p.get('fullurl'),'provider':lang+'.wikipedia.org','score':score(title,p['title'])} for p in d.get('query',{}).get('pages',{}).values() if p.get('thumbnail')]
def anilist(title):
 query='query($search:String){Media(search:$search,type:ANIME){title{romaji english native} coverImage{extraLarge large} siteUrl}}';d=getjson('https://graphql.anilist.co',json.dumps({'query':query,'variables':{'search':title}}).encode()).get('data',{}).get('Media');
 if not d:return []
 names=[x for x in d['title'].values() if x];return [{'title':names[0],'image':d['coverImage'].get('extraLarge') or d['coverImage']['large'],'page':d['siteUrl'],'provider':'anilist.co','score':max(score(title,n) for n in names)+5}]
def jikan(title):
 d=getjson('https://api.jikan.moe/v4/anime?'+urllib.parse.urlencode({'q':title,'limit':5}));out=[]
 for x in d.get('data',[]):
  names=[n for n in [x.get('title'),x.get('title_english'),x.get('title_japanese')] if n];img=x.get('images',{}).get('jpg',{}).get('large_image_url')
  if img:out.append({'title':names[0],'image':img,'page':x.get('url'),'provider':'api.jikan.moe','score':max(score(title,n) for n in names)+4})
 return out
def tvmaze(title):
 d=getjson('https://api.tvmaze.com/search/shows?'+urllib.parse.urlencode({'q':title}));return [{'title':x['show']['name'],'image':x['show']['image'].get('original') or x['show']['image']['medium'],'page':x['show'].get('url'),'provider':'api.tvmaze.com','score':score(title,x['show']['name'])+2} for x in d[:5] if x.get('show',{}).get('image')]
def openlib(title):
 d=getjson('https://openlibrary.org/search.json?'+urllib.parse.urlencode({'title':title,'limit':5,'fields':'key,title,cover_i'}));return [{'title':x['title'],'image':f"https://covers.openlibrary.org/b/id/{x['cover_i']}-L.jpg",'page':'https://openlibrary.org'+x['key'],'provider':'openlibrary.org','score':score(title,x['title'])} for x in d.get('docs',[]) if x.get('cover_i')]
def steam(title):
 d=getjson('https://store.steampowered.com/api/storesearch/?'+urllib.parse.urlencode({'term':title,'l':'english','cc':'US'}));return [{'title':x['name'],'image':x['tiny_image'],'page':f"https://store.steampowered.com/app/{x['id']}",'provider':'store.steampowered.com','score':score(title,x['name'])+3} for x in d.get('items',[])[:5] if x.get('tiny_image')]
def find_cover(title):
 candidates=[]
 with ThreadPoolExecutor(max_workers=7) as ex:
  fs=[ex.submit(f,title) for f in [lambda x:wiki(x,'zh'),lambda x:wiki(x,'en'),anilist,jikan,tvmaze,openlib,steam]]
  for f in as_completed(fs):
   try:candidates.extend(f.result())
   except Exception:pass
 return max(candidates,key=lambda x:x['score']) if candidates else None
def cache_cover(c,id):
 req=urllib.request.Request(c['image'],headers={'User-Agent':UA});res=urllib.request.urlopen(req,timeout=15);typ=res.headers.get_content_type();data=res.read(10*1024*1024+1)
 if not typ.startswith('image/') or len(data)<100 or len(data)>10*1024*1024:raise ValueError('封面图片异常')
 ext='png' if 'png' in typ else 'webp' if 'webp' in typ else 'jpg';name=f'{id}.{ext}';tmp=COVERS/(name+'.tmp');tmp.write_bytes(data);tmp.replace(COVERS/name);return '/covers/'+name
def update_cover(item):
 c=find_cover(item['title']);item.update(cover=None,coverSource=None,coverUpdatedAt=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
 if c:item['cover']=cache_cover(c,item['id']);item['coverSource']=c.get('page')
 item['updatedAt']=item['coverUpdatedAt'];save();return item
def clean_input(x):
 title=str(x.get('title','')).strip()[:160]
 if not title:raise ValueError('请输入标题')
 return title,str(x.get('description','')).strip()[:2000],'completed' if x.get('status')=='completed' else 'active'
class Handler(http.server.BaseHTTPRequestHandler):
 server_version='LibraryManager';sys_version=''
 def log_message(self,fmt,*args):print('%s - %s'%(self.address_string(),fmt%args),flush=True)
 def headers_common(self,ctype='application/json; charset=utf-8',length=None):
  self.send_header('Content-Type',ctype);self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'");
  if length is not None:self.send_header('Content-Length',str(length))
 def json(self,status,obj,cookie=None):
  b=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.headers_common(length=len(b));
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers();self.wfile.write(b)
 def body(self):
  n=int(self.headers.get('Content-Length','0'));return json.loads(self.rfile.read(n) or b'{}')
 def authed(self):
  c=http.cookies.SimpleCookie(self.headers.get('Cookie',''));return verify(c.get('library_session').value if c.get('library_session') else '')
 def require(self):
  if not self.authed():self.json(401,{'error':'请先登录'});return False
  return True
 def do_GET(self):
  p=urllib.parse.urlparse(self.path).path
  if p=='/api/health':return self.json(200,{'ok':True,'items':len(DB['items']),'runtime':'python-native-v3'})
  if p=='/api/me':return self.json(200,{'authenticated':True}) if self.require() else None
  if p=='/api/items':return self.json(200,sorted(DB['items'],key=lambda x:x['updatedAt'],reverse=True)) if self.require() else None
  if p.startswith('/covers/'):
   if not self.require():return
   f=(COVERS/pathlib.Path(p).name);return self.file(f)
  f=(PUBLIC/('index.html' if p=='/' else p.lstrip('/'))).resolve(); pub=PUBLIC.resolve(); safe=(f==pub or pub in f.parents); return self.file(f if safe and f.is_file() else PUBLIC/'index.html')
 def file(self,f):
  if not f.is_file():return self.json(404,{'error':'不存在'})
  typ={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}.get(f.suffix,'application/octet-stream');b=f.read_bytes();self.send_response(200);self.headers_common(typ,len(b));self.end_headers();self.wfile.write(b)
 def do_POST(self):
  p=urllib.parse.urlparse(self.path).path
  if p=='/api/login':
   ip=self.client_address[0];now=time.time();a=ATTEMPTS.get(ip,[0,0])
   if a[1]>now:return self.json(429,{'error':'尝试次数过多，请15分钟后重试'})
   if not check_pw(str(self.body().get('password',''))):
    a[0]+=1
    if a[0]>=8:a=[0,now+900]
    ATTEMPTS[ip]=a;return self.json(401,{'error':'密码错误'})
   ATTEMPTS.pop(ip,None);secure='; Secure' if SECURE else '';return self.json(200,{'ok':True},f'library_session={token()}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000{secure}')
  if p=='/api/logout':return self.json(200,{'ok':True},'library_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
  if not self.require():return
  if p=='/api/items':
   try:
    title,desc,status=clean_input(self.body());now=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());item={'id':str(uuid.uuid4()),'title':title,'description':desc,'status':status,'cover':None,'coverSource':None,'coverUpdatedAt':None,'createdAt':now,'updatedAt':now};DB['items'].append(item);save()
    try:update_cover(item)
    except Exception as e:print('cover:',e,flush=True)
    return self.json(201,item)
   except Exception as e:return self.json(400,{'error':str(e)})
  m=re.fullmatch(r'/api/items/([^/]+)/refresh-cover',p)
  if m:
   item=next((x for x in DB['items'] if x['id']==m.group(1)),None)
   if not item:return self.json(404,{'error':'记录不存在'})
   try:return self.json(200,update_cover(item))
   except Exception as e:return self.json(502,{'error':str(e)})
  return self.json(404,{'error':'不存在'})
 def do_PUT(self):
  if not self.require():return
  m=re.fullmatch(r'/api/items/([^/]+)',urllib.parse.urlparse(self.path).path);item=next((x for x in DB['items'] if m and x['id']==m.group(1)),None)
  if not item:return self.json(404,{'error':'记录不存在'})
  try:
   title,desc,status=clean_input(self.body());changed=title!=item['title'];item.update(title=title,description=desc,status=status,updatedAt=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()));save()
   if changed:
    try:update_cover(item)
    except Exception as e:print('cover:',e,flush=True)
   return self.json(200,item)
  except Exception as e:return self.json(400,{'error':str(e)})
 def do_DELETE(self):
  if not self.require():return
  m=re.fullmatch(r'/api/items/([^/]+)',urllib.parse.urlparse(self.path).path);i=next((i for i,x in enumerate(DB['items']) if m and x['id']==m.group(1)),None)
  if i is None:return self.json(404,{'error':'记录不存在'})
  item=DB['items'].pop(i);save()
  if item.get('cover'):
   try:(COVERS/pathlib.Path(item['cover']).name).unlink()
   except:pass
  return self.json(200,{'ok':True})
class Server(http.server.ThreadingHTTPServer):daemon_threads=True
if __name__=='__main__':print(f'Library Manager v3 listening on {HOST}:{PORT}',flush=True);Server((HOST,PORT),Handler).serve_forever()
