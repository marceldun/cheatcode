#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ] && [ "${LIBRARY_CONFIG_ONLY:-0}" != 1 ] && [ "${LIBRARY_FILES_ONLY:-0}" != 1 ]; then echo "需要root权限。"; exit 1; fi
have(){ command -v "$1" >/dev/null 2>&1; }
if ! have curl || ! have openssl || ! have python3; then
 if have apt-get;then apt-get update -y&&DEBIAN_FRONTEND=noninteractive apt-get install -y curl ca-certificates openssl python3;
 elif have dnf;then dnf install -y curl ca-certificates openssl python3;
 elif have yum;then yum install -y curl ca-certificates openssl python3;
 else echo "无法识别系统包管理器。";exit 1;fi
fi
is_ipv4(){ [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]&&IFS=. read -r a b c d<<<"$1"&&((a<256&&b<256&&c<256&&d<256)); }
find_ip(){ [ -n "${LIBRARY_PUBLIC_IP_OVERRIDE:-}" ]&&{ echo "$LIBRARY_PUBLIC_IP_OVERRIDE";return;};local x;for u in https://api.ipify.org https://ipv4.icanhazip.com https://ifconfig.me/ip;do x="$(curl -4fsS --max-time 8 "$u" 2>/dev/null|tr -d '[:space:]'||true)";is_ipv4 "$x"&&{ echo "$x";return;};done;x="$(ip -4 route get 1.1.1.1 2>/dev/null|awk '{for(i=1;i<=NF;i++)if($i=="src"){print $(i+1);exit}}')";is_ipv4 "$x"&&echo "$x"; }
echo "[1/8] 检查现有配置……"
if [ ! -f .env ];then
 read -rp "请输入域名；没有域名直接按回车，自动使用VPS公网IP: " input;input="$(echo "$input"|xargs)";input="${input#http://}";input="${input#https://}";input="${input%%/*}"
 if [ -z "$input" ];then ip="$(find_ip)";is_ipv4 "$ip"||{ echo "无法取得公网IPv4。";exit 1;};site="http://$ip";secure=false;mode=ip;input="$ip";
 elif is_ipv4 "$input";then site="http://$input";secure=false;mode=ip;
 elif [[ "$input" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]]&&[[ "$input" == *.* ]];then site="https://$input";secure=true;mode=domain;
 else echo "输入既不是有效域名也不是IPv4。";exit 1;fi
 umask 077;printf 'DOMAIN=%s\nPUBLIC_URL=%s\nCOOKIE_SECURE=%s\nACCESS_MODE=%s\nADMIN_PASSWORD=%s\nSESSION_SECRET=%s\n' "$input" "$site" "$secure" "$mode" "$(openssl rand -hex 10)" "$(openssl rand -hex 32)" >.env
else
 input="$(sed -n 's/^DOMAIN=//p' .env)";site="$(sed -n 's/^PUBLIC_URL=//p' .env)";mode="$(sed -n 's/^ACCESS_MODE=//p' .env)";secure="$(sed -n 's/^COOKIE_SECURE=//p' .env)"
 if [ -z "$site" ];then if is_ipv4 "$input";then site="http://$input";mode=ip;secure=false;else site="https://$input";mode=domain;secure=true;fi;printf 'PUBLIC_URL=%s\nCOOKIE_SECURE=%s\nACCESS_MODE=%s\n' "$site" "$secure" "$mode">>.env;fi
fi
password="$(sed -n 's/^ADMIN_PASSWORD=//p' .env)";[ -n "$site" ]&&[ -n "$password" ]||{ echo "配置不完整。";exit 1; }
[ "${LIBRARY_CONFIG_ONLY:-0}" = 1 ]&&{ echo "CONFIG_TEST_PASS $site";exit 0; }
if [ "${LIBRARY_FILES_ONLY:-0}" != 1 ];then
 echo "[Google Images] 无需API Key或cx，进行真实网页图片搜索测试……"
 if ! LIBRARY_TEST_ROOT="$(pwd)" python3 - <<'PYGOOGLE'
import importlib.util,os,pathlib,sys,tempfile,urllib.request
try:
 os.environ.update(DATA_DIR=tempfile.mkdtemp(),ADMIN_PASSWORD='temporary-test-password')
 path=pathlib.Path(os.environ['LIBRARY_TEST_ROOT'])/'app/server.py';spec=importlib.util.spec_from_file_location('library_test',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);result=module.google_images('Spirited Away','anime');assert result.get('image')
 req=urllib.request.Request(result['image'],headers={'User-Agent':module.UA});response=urllib.request.urlopen(req,timeout=20);assert response.headers.get_content_type().startswith('image/') and len(response.read(256))>100;print('GOOGLE_IMAGES_NO_KEY_LIVE_TEST_PASS')
except Exception as e:print('Google Images无密钥搜索失败：'+str(e),file=sys.stderr);sys.exit(1)
PYGOOGLE
 then
  exit 1
 fi
fi
sed -i '/^GEMINI_/d;/^GOOGLE_IMAGES_API_KEY=/d;/^GOOGLE_IMAGES_CX=/d' .env
echo "[2/8] 清理v2失败产生的Docker构建缓存，不接触其他运行中容器……"
if have docker && [ "${LIBRARY_FILES_ONLY:-0}" != 1 ];then
 ids="$(docker ps -aq --filter label=com.docker.compose.project=media-library 2>/dev/null||true)";[ -z "$ids" ]||docker rm -f $ids >/dev/null 2>&1||true
 docker builder prune -af >/dev/null 2>&1||true
 docker image rm media-library-app personal-media-library:test node:24-alpine caddy:2.10-alpine >/dev/null 2>&1||true
 docker image prune -f >/dev/null 2>&1||true
fi
echo "[3/8] 安装不足1MB的原生Python服务……"
target_app="${LIBRARY_APP_TARGET:-/opt/personal-media-library/app}";source_app="$(readlink -f app)";target_real="$(readlink -m "$target_app")"
install -d -m755 "$target_app"
chmod 755 "$target_app"
if [ "$source_app" = "$target_real" ];then echo "程序已经位于最终目录，跳过重复复制。";else cp -a app/. "$target_app/";fi
if [ "${LIBRARY_FILES_ONLY:-0}" = 1 ];then echo "FILES_INSTALL_TEST_PASS";exit 0;fi
install -d -m755 /var/lib/personal-media-library/covers
if [ -d /var/lib/docker/volumes/media-library_library_data/_data ];then cp -an /var/lib/docker/volumes/media-library_library_data/_data/. /var/lib/personal-media-library/ 2>/dev/null||true;fi
id media-library >/dev/null 2>&1||useradd --system --home /var/lib/personal-media-library --shell /usr/sbin/nologin media-library
chown -R media-library:media-library /var/lib/personal-media-library;chmod 755 /opt /opt/personal-media-library /opt/personal-media-library/app;chmod -R a=rX /opt/personal-media-library/app
if have runuser;then runuser -u media-library -- test -r /opt/personal-media-library/app/server.py;else su -s /bin/sh media-library -c "test -r /opt/personal-media-library/app/server.py";fi||{ echo "服务用户仍无法读取server.py。";have namei&&namei -l /opt/personal-media-library/app/server.py;exit 1;}
systemctl stop personal-media-library.service caddy-library.service >/dev/null 2>&1||true
port_free(){ python3 - "$1" <<'PYPORT'
import socket,sys
s=socket.socket();
try:s.bind(('0.0.0.0',int(sys.argv[1])));print('yes')
except OSError:print('no')
finally:s.close()
PYPORT
}
if [ "$mode" = domain ];then port=39080;host=127.0.0.1;[ "$(port_free "$port")" = yes ]||port=39081
else
 host=0.0.0.0;port=""
 for candidate in 80 8080 18080 30080;do [ "$(port_free "$candidate")" = yes ]&&{ port="$candidate";break;};done
 [ -n "$port" ]||{ echo "80、8080、18080、30080端口全部被占用。";exit 1; }
 if [ "$port" != 80 ];then site="http://$input:$port";tmpenv="$(mktemp)";grep -v '^PUBLIC_URL=' .env>"$tmpenv";echo "PUBLIC_URL=$site">>"$tmpenv";cat "$tmpenv">.env;rm -f "$tmpenv";echo "80端口已占用，自动改用：$site";fi
fi
grep -vE '^(DATA_DIR|PORT|HOST)=' .env >/tmp/library-env.$$;printf 'DATA_DIR=/var/lib/personal-media-library\nPORT=%s\nHOST=%s\n' "$port" "$host">>/tmp/library-env.$$;install -m600 /tmp/library-env.$$ /etc/personal-media-library.env;rm -f /tmp/library-env.$$
cat >/etc/systemd/system/personal-media-library.service <<'UNIT'
[Unit]
Description=Personal Media Library v10
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=60
StartLimitBurst=5
[Service]
Type=simple
User=media-library
Group=media-library
EnvironmentFile=/etc/personal-media-library.env
ExecStart=/usr/bin/python3 /opt/personal-media-library/app/server.py
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/personal-media-library
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
[Install]
WantedBy=multi-user.target
UNIT
if [ "$mode" = domain ];then
 echo "[4/8] 安装轻量HTTPS入口……";arch="$(uname -m)";case "$arch" in x86_64)ca=amd64;;aarch64|arm64)ca=arm64;;*)echo "暂不支持CPU架构$arch";exit 1;;esac
 tmp="$(mktemp -d)";curl -fL --retry 5 "https://github.com/caddyserver/caddy/releases/download/v2.10.2/caddy_2.10.2_linux_${ca}.tar.gz" -o "$tmp/caddy.tgz";tar xzf "$tmp/caddy.tgz" -C "$tmp" caddy;install -m755 "$tmp/caddy" /usr/local/bin/caddy;rm -rf "$tmp";id caddy>/dev/null 2>&1||useradd --system --home /var/lib/caddy --shell /usr/sbin/nologin caddy;install -d -o caddy -g caddy /var/lib/caddy /etc/caddy
 cat >/etc/caddy/Caddyfile <<CADDY
$input {
 encode zstd gzip
 reverse_proxy 127.0.0.1:39080
}
CADDY
 cat >/etc/systemd/system/caddy-library.service <<'UNIT'
[Unit]
Description=Caddy for Personal Media Library
After=network-online.target personal-media-library.service
[Service]
User=caddy
Group=caddy
ExecStart=/usr/local/bin/caddy run --config /etc/caddy/Caddyfile
ExecReload=/usr/local/bin/caddy reload --config /etc/caddy/Caddyfile
Restart=always
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
[Install]
WantedBy=multi-user.target
UNIT
else echo "[4/8] IP模式无需Docker、Node或HTTPS组件。";systemctl disable --now caddy-library.service >/dev/null 2>&1||true;fi
if have ufw&&ufw status|grep -q '^Status: active';then ufw allow "$port/tcp">/dev/null;[ "$mode" = domain ]&&ufw allow 443/tcp>/dev/null;fi
echo "[5/8] 启动并设置开机自动运行……";systemctl daemon-reload;systemctl reset-failed personal-media-library.service >/dev/null 2>&1||true;systemctl enable --now personal-media-library.service;[ "$mode" = domain ]&&systemctl enable --now caddy-library.service
for _ in $(seq 1 40);do curl -fsS --max-time 3 "http://127.0.0.1:$port/api/health">/dev/null 2>&1&&break;sleep 1;done
curl -fsS "http://127.0.0.1:$port/api/health">/dev/null||{ journalctl -u personal-media-library -n100 --no-pager;exit 1; }
echo "[6/8] 测试会员、后台权限、三分类和Google Images即时封面……"
PORT_TEST="$port" PASSWORD_TEST="$password" python3 - <<'PY'
import http.cookiejar,json,os,time,urllib.request,uuid
base='http://127.0.0.1:'+os.environ['PORT_TEST']
def client():
 jar=http.cookiejar.CookieJar();return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def req(op,path,data=None,method=None):
 body=json.dumps(data).encode() if data is not None else None
 r=op.open(urllib.request.Request(base+path,body,{'Content-Type':'application/json'},method=method),timeout=10);return json.loads(r.read())
a,b=client(),client();suffix=uuid.uuid4().hex[:10]
req(a,'/api/login',{'username':'admin','password':os.environ['PASSWORD_TEST']})
start=time.monotonic();x=req(a,'/api/items',{'title':'進撃の巨人','description':'v10 self test','status':'active','mediaType':'anime'});elapsed=time.monotonic()-start
assert elapsed<1 and x['cover'].endswith('.svg')
img=a.open(base+x['cover'],timeout=5);assert img.headers.get_content_type()=='image/svg+xml'
req(b,'/api/register',{'username':'test_'+suffix,'password':'TestPass_'+suffix})
assert req(b,'/api/items')==[]
y=req(b,'/api/items',{'title':'Monster Hunter','description':'v10 self test','status':'active','mediaType':'game'})
assert y['mediaType']=='game' and all(i['id']!=x['id'] for i in req(b,'/api/items'))
req(a,'/api/items/'+x['id'],method='DELETE');req(b,'/api/items/'+y['id'],method='DELETE');req(b,'/api/account',method='DELETE')
health=req(a,'/api/health');assert health['runtime']=='python-native-v10' and health['googleImagesConfigured'] and health['googleImagesMode']=='no-key-web'
overview=req(a,'/api/admin/overview');assert overview['googleImagesConfigured'] and len(overview['users'])>=1
print('V10_FULL_FLOW_PASS instant_seconds=%.4f'%elapsed)
PY
echo "[7/8] 验证公网访问……";ok="";for _ in $(seq 1 60);do curl -fsS --max-time 10 "$site/api/health">/dev/null 2>&1&&{ ok=1;break;};sleep 3;done;[ -n "$ok" ]||{ echo "公网访问失败，请检查VPS安全组是否放行80端口；域名模式还需443端口。";exit 1; }
echo "[8/8] 所有验证通过。";printf '\n网站：%s\n管理员用户名：admin\n管理员密码：%s\nGoogle Images封面：无密钥模式已验证\n' "$site" "$password"
