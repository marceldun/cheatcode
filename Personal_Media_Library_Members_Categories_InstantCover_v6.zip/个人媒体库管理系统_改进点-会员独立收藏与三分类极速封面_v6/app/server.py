#!/usr/bin/env python3
import base64,difflib,hashlib,hmac,html,http.cookies,http.server,json,os,pathlib,re,secrets,shutil,threading,time,urllib.parse,urllib.request,uuid
from concurrent.futures import ThreadPoolExecutor,as_completed
ROOT=pathlib.Path(__file__).resolve().parent;PUBLIC=ROOT/'public';DATA=pathlib.Path(os.environ.get('DATA_DIR','/var/lib/personal-media-library'));COVERS=DATA/'covers';CACHE=DATA/'cover-cache';PORT=int(os.environ.get('PORT','8080'));HOST=os.environ.get('HOST','0.0.0.0');SECRET=os.environ.get('SESSION_SECRET') or secrets.token_hex(32);SECURE=os.environ.get('COOKIE_SECURE','false').lower()=='true';UA='PersonalMediaLibrary/6.0'
for d in(DATA,COVERS,CACHE):d.mkdir(parents=True,exist_ok=True)
LIB=DATA/'library.json';USERS_FILE=DATA/'users.json';SETTINGS=DATA/'settings.json';INDEX_FILE=DATA/'cover-index.json';LOCK=threading.RLock();ATTEMPTS={};JOBS={};POOL=ThreadPoolExecutor(max_workers=3)
def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def atomic(p,o):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(o,ensure_ascii=False,indent=2),'utf-8');os.chmod(t,0o600);t.replace(p)
def read(p,d):
 try:return json.loads(p.read_text('utf-8'))
 except:return d
def phash(p,s=None):s=s or secrets.token_bytes(16);return s.hex()+':'+hashlib.scrypt(p.encode(),salt=s,n=16384,r=8,p=1).hex()
def pcheck(p,h):
 try:s,d=h.split(':');return hmac.compare_digest(phash(p,bytes.fromhex(s)).split(':')[1],d)
 except:return False
def loadusers():
 u=read(USERS_FILE,{'version':6,'users':[]})
 if u['users']:return u
 old=read(SETTINGS,{}).get('passwordHash');password=os.environ.get('ADMIN_PASSWORD','')
 if not old and len(password)<10:raise RuntimeError('ADMIN_PASSWORD必须至少10位')
 u['users']=[{'id':'admin','username':'admin','key':'admin','passwordHash':old or phash(password),'role':'admin','createdAt':now()}];atomic(USERS_FILE,u);return u
USERS=loadusers()
def loadlib():
 d=read(LIB,{'version':6,'items':[]});d['items']=d.get('items',[]);changed=d.get('version')!=6;d['version']=6
 for x in d['items']:
  if not x.get('ownerId'):x['ownerId']='admin';changed=True
  if x.get('mediaType')not in('anime','manga','game'):x['mediaType']='anime';changed=True
  if not x.get('coverStatus'):x['coverStatus']='ready' if x.get('cover')else'fallback';changed=True
 if changed:atomic(LIB,d)
 return d
DB=loadlib();CINDEX=read(INDEX_FILE,{'entries':{}})
def savedb():
 with LOCK:
  if LIB.exists():shutil.copy2(LIB,DATA/'library.backup.json')
  atomic(LIB,DB)
def saveusers():
 with LOCK:atomic(USERS_FILE,USERS)
def user_name(n):return next((u for u in USERS['users']if u['key']==n.strip().casefold()),None)
def user_id(i):return next((u for u in USERS['users']if u['id']==i),None)
def token(uid):
 b=base64.urlsafe_b64encode(json.dumps({'uid':uid,'exp':int(time.time())+2592000}).encode()).rstrip(b'=');s=hmac.new(SECRET.encode(),b,hashlib.sha256).digest();return b.decode()+'.'+base64.urlsafe_b64encode(s).rstrip(b'=').decode()
def verify(v):
 try:
  b,s=v.split('.');pad=lambda x:x+'='*(-len(x)%4);good=hmac.compare_digest(base64.urlsafe_b64decode(pad(s)),hmac.new(SECRET.encode(),b.encode(),hashlib.sha256).digest());d=json.loads(base64.urlsafe_b64decode(pad(b)));return d['uid']if good and d['exp']>time.time()and user_id(d['uid'])else None
 except:return None
def norm(s):return''.join(c for c in s.casefold()if c.isalnum())
def score(q,t):
 q,t=norm(q),norm(t)
 if not q or not t:return 0
 if q==t:return 100
 r=difflib.SequenceMatcher(None,q,t).ratio()*100
 if q in t or t in q:r=max(r,82-min(20,abs(len(q)-len(t))))
 return round(r,2)
def getjson(url,data=None):
 req=urllib.request.Request(url,data=data,headers={'User-Agent':UA,'Content-Type':'application/json'});return json.loads(urllib.request.urlopen(req,timeout=6).read())
def wiki(title,lang):
 q=urllib.parse.urlencode({'action':'query','format':'json','generator':'search','gsrsearch':title,'gsrlimit':5,'prop':'pageimages|info','inprop':'url','piprop':'thumbnail','pithumbsize':800});d=getjson(f'https://{lang}.wikipedia.org/w/api.php?{q}');return[{'names':[p['title']],'image':p['thumbnail']['source'],'page':p.get('fullurl')}for p in d.get('query',{}).get('pages',{}).values()if p.get('thumbnail')]
def anilist(title,kind):
 q='query($search:String,$type:MediaType){Media(search:$search,type:$type){title{romaji english native} synonyms coverImage{extraLarge large} siteUrl}}';d=getjson('https://graphql.anilist.co',json.dumps({'query':q,'variables':{'search':title,'type':'MANGA'if kind=='manga'else'ANIME'}}).encode()).get('data',{}).get('Media')
 if not d:return[]
 return[{'names':[x for x in list(d['title'].values())+d.get('synonyms',[])if x],'image':d['coverImage'].get('extraLarge')or d['coverImage'].get('large'),'page':d.get('siteUrl')}]
def jikan(title,kind):
 ep='manga'if kind=='manga'else'anime';d=getjson(f'https://api.jikan.moe/v4/{ep}?'+urllib.parse.urlencode({'q':title,'limit':5}));out=[]
 for x in d.get('data',[]):
  names=[v for v in[x.get('title'),x.get('title_english'),x.get('title_japanese')]+[y.get('title')for y in x.get('titles',[])]if v];img=x.get('images',{}).get('jpg',{}).get('large_image_url')
  if img:out.append({'names':names,'image':img,'page':x.get('url')})
 return out
def books(title):
 d=getjson('https://openlibrary.org/search.json?'+urllib.parse.urlencode({'q':title,'limit':5,'fields':'key,title,cover_i,alternative_title'}));return[{'names':[x['title']]+x.get('alternative_title',[])[:8],'image':f"https://covers.openlibrary.org/b/id/{x['cover_i']}-L.jpg",'page':'https://openlibrary.org'+x['key']}for x in d.get('docs',[])if x.get('cover_i')]
def steam(title):
 d=getjson('https://store.steampowered.com/api/storesearch/?'+urllib.parse.urlencode({'term':title,'l':'schinese','cc':'US'}));return[{'names':[x['name']],'image':x['tiny_image'].replace('capsule_sm_120','library_600x900_2x'),'page':f"https://store.steampowered.com/app/{x['id']}"}for x in d.get('items',[])[:8]if x.get('tiny_image')]
def findcover(title,kind):
 fs=[lambda:wiki(title,'zh'),lambda:wiki(title,'ja'),lambda:wiki(title,'en')]
 if kind in('anime','manga'):fs +=[lambda:anilist(title,kind),lambda:jikan(title,kind)]
 if kind=='manga':fs +=[lambda:books(title)]
 if kind=='game':fs +=[lambda:steam(title)]
 out=[]
 with ThreadPoolExecutor(max_workers=len(fs))as ex:
  for f in as_completed([ex.submit(x)for x in fs]):
   try:out.extend(f.result())
   except:pass
 for c in out:c['score']=max((score(title,n)for n in c['names']),default=0)
 return max(out,key=lambda x:x['score'])if out else None
def placeholder(x):
 label={'anime':'动漫','manga':'漫画','game':'游戏'}[x['mediaType']];a,b={'anime':('#6d28d9','#db2777'),'manga':('#0f766e','#0891b2'),'game':('#b45309','#dc2626')}[x['mediaType']];title=html.escape(x['title'][:18]);svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient></defs><rect width="600" height="800" fill="url(#g)"/><text x="50%" y="43%" text-anchor="middle" fill="white" font-size="42" font-family="sans-serif">{title}</text><text x="50%" y="52%" text-anchor="middle" fill="white" font-size="26" font-family="sans-serif">{label} · 匹配中</text></svg>';name=x['id']+'.svg';(COVERS/name).write_text(svg,'utf-8');return'/covers/'+name
def ckey(t,k):return k+':'+norm(t)
def cached(x,key):
 e=CINDEX['entries'].get(key);src=CACHE/e['file']if e else None
 if not src or not src.is_file():return False
 target=COVERS/(x['id']+src.suffix);shutil.copyfile(src,target);old=x.get('cover');x.update(cover='/covers/'+target.name,coverSource=e.get('source'),coverStatus='ready',coverUpdatedAt=now(),updatedAt=now())
 if old and old!=x['cover']:
  try:(COVERS/pathlib.Path(old).name).unlink()
  except:pass
 savedb();return True
def worker(i,uid,force=False):
 try:
  x=next((z for z in DB['items']if z['id']==i and z['ownerId']==uid),None)
  if not x:return
  key=ckey(x['title'],x['mediaType'])
  if not force and cached(x,key):return
  c=findcover(x['title'],x['mediaType'])
  if c:
   req=urllib.request.Request(c['image'],headers={'User-Agent':UA});res=urllib.request.urlopen(req,timeout=12);typ=res.headers.get_content_type();data=res.read(10485761)
   if not typ.startswith('image/')or not 100<len(data)<=10485760:raise ValueError('bad image')
   ext='.png'if'png'in typ else'.webp'if'webp'in typ else'.jpg';name=hashlib.sha256(key.encode()).hexdigest()+ext;(CACHE/name).write_bytes(data);CINDEX['entries'][key]={'file':name,'source':c.get('page'),'score':c['score'],'updatedAt':now()};atomic(INDEX_FILE,CINDEX);cached(x,key);return
  x['coverStatus']='fallback';x['coverUpdatedAt']=now();savedb()
 except Exception as e:print('cover:',e,flush=True)
 finally:JOBS.pop(i,None)
def schedule(x,force=False):
 if x['id']not in JOBS:JOBS[x['id']]=POOL.submit(worker,x['id'],x['ownerId'],force)
def clean(d):
 title=str(d.get('title','')).strip()[:160];kind=d.get('mediaType','anime')
 if not title:raise ValueError('请输入标题')
 if kind not in('anime','manga','game'):raise ValueError('分类无效')
 return title,str(d.get('description','')).strip()[:2000],'completed'if d.get('status')=='completed'else'active',kind
class Handler(http.server.BaseHTTPRequestHandler):
 server_version='LibraryManager';sys_version=''
 def log_message(self,f,*a):print(f%a,flush=True)
 def common(self,t='application/json; charset=utf-8',n=None):
  self.send_header('Content-Type',t);self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Cache-Control','no-store');self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'")
  if n is not None:self.send_header('Content-Length',str(n))
 def json(self,s,o,c=None):
  b=json.dumps(o,ensure_ascii=False).encode();self.send_response(s);self.common(n=len(b));
  if c:self.send_header('Set-Cookie',c)
  self.end_headers();self.wfile.write(b)
 def body(self):
  n=int(self.headers.get('Content-Length','0'))
  if n>32768:raise ValueError('请求过大')
  return json.loads(self.rfile.read(n)or b'{}')
 def uid(self):
  c=http.cookies.SimpleCookie(self.headers.get('Cookie',''));v=c.get('library_session');return verify(v.value)if v else None
 def require(self):
  u=self.uid()
  if not u:self.json(401,{'error':'请先登录'})
  return u
 def cookie(self,u):return f'library_session={token(u)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000'+('; Secure'if SECURE else'')
 def file(self,p):
  if not p.is_file():return self.json(404,{'error':'不存在'})
  typ={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'}.get(p.suffix,'application/octet-stream');b=p.read_bytes();self.send_response(200);self.common(typ,len(b));self.end_headers();self.wfile.write(b)
 def do_GET(self):
  p=urllib.parse.urlparse(self.path).path
  if p=='/api/health':return self.json(200,{'ok':True,'runtime':'python-native-v6'})
  if p=='/api/me':
   u=self.require()
   if u:
    x=user_id(u);return self.json(200,{'authenticated':True,'username':x['username'],'role':x['role']})
   return
  if p=='/api/items':
   u=self.require()
   if u:return self.json(200,sorted([x for x in DB['items']if x['ownerId']==u],key=lambda x:x['updatedAt'],reverse=True))
   return
  if p.startswith('/covers/'):
   if self.require():return self.file(COVERS/pathlib.Path(p).name)
   return
  f=(PUBLIC/('index.html'if p=='/'else p.lstrip('/'))).resolve();pub=PUBLIC.resolve();return self.file(f if pub in f.parents and f.is_file()else PUBLIC/'index.html')
 def do_POST(self):
  p=urllib.parse.urlparse(self.path).path
  if p in('/api/login','/api/register'):
   key=(self.client_address[0],p);count,until=ATTEMPTS.get(key,[0,0])
   if until>time.time():return self.json(429,{'error':'尝试次数过多，请15分钟后重试'})
   ATTEMPTS[key]=[0,time.time()+900]if count>=11 else[count+1,0]
   try:d=self.body();name=str(d.get('username','')).strip();password=str(d.get('password',''))
   except Exception as e:return self.json(400,{'error':str(e)})
   if p=='/api/register':
    if not re.fullmatch(r'[\w\-\u4e00-\u9fff\u3040-\u30ff]{3,32}',name,re.U):return self.json(400,{'error':'用户名需为3–32位文字、字母、数字、下划线或短横线'})
    if not 8<=len(password)<=128:return self.json(400,{'error':'密码需为8–128位'})
    if user_name(name):return self.json(409,{'error':'用户名已存在'})
    x={'id':str(uuid.uuid4()),'username':name,'key':name.casefold(),'passwordHash':phash(password),'role':'member','createdAt':now()};USERS['users'].append(x);saveusers();return self.json(201,{'ok':True},self.cookie(x['id']))
   x=user_name(name)
   if not x or not pcheck(password,x['passwordHash']):return self.json(401,{'error':'用户名或密码错误'})
   ATTEMPTS.pop(key,None);return self.json(200,{'ok':True},self.cookie(x['id']))
  if p=='/api/logout':return self.json(200,{'ok':True},'library_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0')
  u=self.require()
  if not u:return
  if p=='/api/items':
   try:
    title,desc,status,kind=clean(self.body());stamp=now();x={'id':str(uuid.uuid4()),'ownerId':u,'title':title,'description':desc,'status':status,'mediaType':kind,'cover':None,'coverSource':None,'coverStatus':'pending','coverUpdatedAt':None,'createdAt':stamp,'updatedAt':stamp};x['cover']=placeholder(x);DB['items'].append(x);savedb()
    if not cached(x,ckey(title,kind)):schedule(x)
    return self.json(201,x)
   except Exception as e:return self.json(400,{'error':str(e)})
  m=re.fullmatch(r'/api/items/([^/]+)/refresh-cover',p);x=next((z for z in DB['items']if m and z['id']==m.group(1)and z['ownerId']==u),None)
  if m:
   if not x:return self.json(404,{'error':'记录不存在'})
   x['coverStatus']='pending';savedb();schedule(x,True);return self.json(202,x)
  return self.json(404,{'error':'不存在'})
 def do_PUT(self):
  u=self.require()
  if not u:return
  m=re.fullmatch(r'/api/items/([^/]+)',urllib.parse.urlparse(self.path).path);x=next((z for z in DB['items']if m and z['id']==m.group(1)and z['ownerId']==u),None)
  if not x:return self.json(404,{'error':'记录不存在'})
  try:
   title,desc,status,kind=clean(self.body());changed=title!=x['title']or kind!=x['mediaType'];x.update(title=title,description=desc,status=status,mediaType=kind,updatedAt=now())
   if changed:x['coverStatus']='pending';x['cover']=placeholder(x)
   savedb()
   if changed and not cached(x,ckey(title,kind)):schedule(x)
   return self.json(200,x)
  except Exception as e:return self.json(400,{'error':str(e)})
 def do_DELETE(self):
  u=self.require()
  if not u:return
  path=urllib.parse.urlparse(self.path).path
  if path=='/api/account':
   account=user_id(u)
   if account['role']=='admin':return self.json(403,{'error':'管理员账号不能删除'})
   owned=[x for x in DB['items']if x['ownerId']==u];DB['items'][:]=[x for x in DB['items']if x['ownerId']!=u];USERS['users'][:]=[x for x in USERS['users']if x['id']!=u]
   for x in owned:
    try:(COVERS/pathlib.Path(x.get('cover','')).name).unlink()
    except:pass
   savedb();saveusers();return self.json(200,{'ok':True},'library_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0')
  m=re.fullmatch(r'/api/items/([^/]+)',path);i=next((i for i,x in enumerate(DB['items'])if m and x['id']==m.group(1)and x['ownerId']==u),None)
  if i is None:return self.json(404,{'error':'记录不存在'})
  x=DB['items'].pop(i);savedb()
  try:(COVERS/pathlib.Path(x['cover']).name).unlink()
  except:pass
  return self.json(200,{'ok':True})
class Server(http.server.ThreadingHTTPServer):daemon_threads=True
if __name__=='__main__':print(f'Library Manager v6 {HOST}:{PORT}',flush=True);Server((HOST,PORT),Handler).serve_forever()
