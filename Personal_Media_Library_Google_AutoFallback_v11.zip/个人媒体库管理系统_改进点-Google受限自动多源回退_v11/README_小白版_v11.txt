个人媒体库管理系统 v11
改进点：Google受限时自动多源回退，封面故障不再阻止安装

完整独立版本，v1-v10保留。

封面顺序：Google Images优先；Google被VPS地区或机房限制时，自动改用AniList、Jikan/MAL、Steam、OpenLibrary、中文/日文/英文Wikipedia。
所有外部来源暂时不可用时，网站仍完成安装并显示1秒内生成的本地即时封面，后台任务以后可重新搜索。
不需要API Key、cx、Gemini或任何Google代码。

安装时只粘贴一行发布命令。原网站、账号、密码、收藏和后台设置继续保留。
