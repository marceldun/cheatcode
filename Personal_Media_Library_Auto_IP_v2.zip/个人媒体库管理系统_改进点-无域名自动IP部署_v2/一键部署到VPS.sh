#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [ "$(id -u)" -ne 0 ] && [ "${LIBRARY_CONFIG_ONLY:-0}" != 1 ]; then echo "需要管理员权限，请使用提供的一键命令运行。"; exit 1; fi
if ! command -v curl >/dev/null 2>&1 || ! command -v openssl >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get install -y curl ca-certificates openssl;
  elif command -v dnf >/dev/null 2>&1; then dnf install -y curl ca-certificates openssl;
  elif command -v yum >/dev/null 2>&1; then yum install -y curl ca-certificates openssl;
  else echo "系统缺少curl/openssl且无法识别包管理器。"; exit 1; fi
fi
if ! command -v docker >/dev/null 2>&1 && [ "${LIBRARY_CONFIG_ONLY:-0}" != 1 ]; then
  echo "[1/7] 自动安装Docker……"; curl -fsSL https://get.docker.com | sh; systemctl enable --now docker
else echo "[1/7] Docker已存在或正在执行配置测试。"; fi
if [ "${LIBRARY_CONFIG_ONLY:-0}" != 1 ]; then docker compose version >/dev/null 2>&1 || { echo "Docker Compose不可用，请更新Docker。"; exit 1; }; fi
is_ipv4(){ [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] && IFS=. read -r a b c d <<<"$1" && ((a<256&&b<256&&c<256&&d<256)); }
find_public_ip(){
  if [ -n "${LIBRARY_PUBLIC_IP_OVERRIDE:-}" ]; then printf '%s' "$LIBRARY_PUBLIC_IP_OVERRIDE"; return; fi
  local value=""
  for endpoint in https://api.ipify.org https://ipv4.icanhazip.com https://ifconfig.me/ip; do value="$(curl -4fsS --max-time 8 "$endpoint" 2>/dev/null | tr -d '[:space:]' || true)"; is_ipv4 "$value" && { printf '%s' "$value"; return; }; done
  value="$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++)if($i=="src"){print $(i+1);exit}}')"; is_ipv4 "$value" && { printf '%s' "$value"; return; }
  return 1
}
if [ ! -f .env ]; then
  echo "[2/7] 配置访问地址。"
  read -rp "请输入域名；没有域名直接按回车，自动使用VPS公网IP: " input
  input="$(printf '%s' "$input" | xargs)"; input="${input#http://}"; input="${input#https://}"; input="${input%%/*}"
  if [ -z "$input" ]; then
    ip="$(find_public_ip)" || { echo "无法自动获取公网IPv4。"; exit 1; }
    site_address="http://$ip"; public_url="$site_address"; cookie_secure=false; mode=ip
    echo "未填写域名，已自动使用公网IP：$ip"
  elif is_ipv4 "$input"; then
    site_address="http://$input"; public_url="$site_address"; cookie_secure=false; mode=ip
    echo "检测到IP地址，将使用HTTP访问。"
  elif [[ "$input" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] && [[ "$input" == *.* ]]; then
    site_address="$input"; public_url="https://$input"; cookie_secure=true; mode=domain
  else echo "输入既不是有效域名也不是IPv4地址。"; exit 1; fi
  password="$(openssl rand -hex 10)"; secret="$(openssl rand -hex 32)"; umask 077
  printf 'DOMAIN=%s\nSITE_ADDRESS=%s\nPUBLIC_URL=%s\nCOOKIE_SECURE=%s\nACCESS_MODE=%s\nADMIN_PASSWORD=%s\nSESSION_SECRET=%s\n' "$input" "$site_address" "$public_url" "$cookie_secure" "$mode" "$password" "$secret" > .env
else
  # 自动兼容v1的旧.env，不删除原密码或数据。
  domain="$(sed -n 's/^DOMAIN=//p' .env)"; password="$(sed -n 's/^ADMIN_PASSWORD=//p' .env)"
  if ! grep -q '^SITE_ADDRESS=' .env; then
    if is_ipv4 "$domain"; then site_address="http://$domain"; public_url="$site_address"; cookie_secure=false; mode=ip; else site_address="$domain"; public_url="https://$domain"; cookie_secure=true; mode=domain; fi
    printf 'SITE_ADDRESS=%s\nPUBLIC_URL=%s\nCOOKIE_SECURE=%s\nACCESS_MODE=%s\n' "$site_address" "$public_url" "$cookie_secure" "$mode" >> .env
  else site_address="$(sed -n 's/^SITE_ADDRESS=//p' .env)"; public_url="$(sed -n 's/^PUBLIC_URL=//p' .env)"; fi
  echo "[2/7] 沿用现有访问地址和数据。"
fi
password="${password:-$(sed -n 's/^ADMIN_PASSWORD=//p' .env)}"; public_url="${public_url:-$(sed -n 's/^PUBLIC_URL=//p' .env)}"
[ -n "$public_url" ] && [ -n "$password" ] || { echo ".env配置不完整。"; exit 1; }
if [ "${LIBRARY_CONFIG_ONLY:-0}" = 1 ]; then echo "CONFIG_TEST_PASS $public_url"; exit 0; fi
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q '^Status: active'; then ufw allow 80/tcp >/dev/null; [ "$(sed -n 's/^ACCESS_MODE=//p' .env)" = domain ] && ufw allow 443/tcp >/dev/null; fi
echo "[3/7] 构建并启动网站……"; docker compose up -d --build
echo "[4/7] 等待应用健康检查……"; status=""
for _ in $(seq 1 90); do status="$(docker inspect --format '{{.State.Health.Status}}' "$(docker compose ps -q app)" 2>/dev/null || true)"; [ "$status" = healthy ] && break; sleep 2; done
[ "$status" = healthy ] || { docker compose logs --tail=150; echo "应用启动失败。"; exit 1; }
echo "[5/7] 执行真实登录、添加、自动封面下载、图片读取、删除测试……"
docker compose exec -T app node --input-type=module - <<'JS'
const base='http://127.0.0.1:3000';const login=await fetch(base+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:process.env.ADMIN_PASSWORD})});if(!login.ok)throw new Error('登录自检失败');const cookie=login.headers.get('set-cookie').split(';')[0],headers={'Content-Type':'application/json','Cookie':cookie};const created=await fetch(base+'/api/items',{method:'POST',headers,body:JSON.stringify({title:'Attack on Titan',description:'deployment self test',status:'active'})});if(!created.ok)throw new Error('添加自检失败 '+await created.text());const item=await created.json();if(!item.cover)throw new Error('所有在线封面来源均未返回图片，请检查VPS网络');const image=await fetch(base+item.cover,{headers:{Cookie:cookie}});if(!image.ok||!(image.headers.get('content-type')||'').startsWith('image/'))throw new Error('封面缓存读取失败');const removed=await fetch(base+'/api/items/'+item.id,{method:'DELETE',headers});if(!removed.ok)throw new Error('删除自检失败');console.log('应用全流程与真实封面下载：PASS');
JS
echo "[6/7] 等待公网地址上线……"; online=""
for _ in $(seq 1 60); do if curl -fsS --max-time 10 "$public_url/api/health" >/dev/null 2>&1; then online=yes; break; fi; sleep 3; done
[ "$online" = yes ] || { docker compose logs --tail=150 caddy; echo "公网访问未成功。请确认80端口未被其他程序占用；域名模式还需开放443端口。"; exit 1; }
echo "[7/7] 所有验证通过。"
printf '\n========================================\n网站：%s\n管理员密码：%s\n========================================\n请保存密码。它也保存在：%s/.env\n' "$public_url" "$password" "$PWD"
