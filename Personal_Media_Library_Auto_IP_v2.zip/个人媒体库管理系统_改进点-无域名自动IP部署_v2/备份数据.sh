#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
mkdir -p backups
name="library-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
docker run --rm -v media-library_library_data:/data:ro -v "$PWD/backups:/backup" alpine tar czf "/backup/$name" -C /data .
echo "备份完成：$PWD/backups/$name"
