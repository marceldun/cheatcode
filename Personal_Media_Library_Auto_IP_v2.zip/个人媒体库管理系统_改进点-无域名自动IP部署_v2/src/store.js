import { mkdir, readFile, rename, writeFile, copyFile } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export class Store {
  constructor(dataDir) {
    this.dir = dataDir;
    this.file = path.join(dataDir, 'library.json');
    this.backup = path.join(dataDir, 'library.backup.json');
    this.data = { version: 1, items: [] };
    this.queue = Promise.resolve();
  }
  async init() {
    await mkdir(path.join(this.dir, 'covers'), { recursive: true });
    try {
      const parsed = JSON.parse(await readFile(this.file, 'utf8'));
      if (!Array.isArray(parsed.items)) throw new Error('items is not an array');
      this.data = parsed;
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      await this.save();
    }
  }
  list() { return [...this.data.items].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); }
  get(id) { return this.data.items.find(item => item.id === id); }
  async create(input) {
    const now = new Date().toISOString();
    const item = { id: crypto.randomUUID(), title: input.title, description: input.description || '', status: input.status, cover: null, coverSource: null, coverUpdatedAt: null, createdAt: now, updatedAt: now };
    this.data.items.push(item); await this.save(); return item;
  }
  async update(id, patch) {
    const item = this.get(id); if (!item) return null;
    Object.assign(item, patch, { updatedAt: new Date().toISOString() }); await this.save(); return item;
  }
  async remove(id) {
    const index = this.data.items.findIndex(item => item.id === id); if (index < 0) return null;
    const [item] = this.data.items.splice(index, 1); await this.save(); return item;
  }
  async save() {
    this.queue = this.queue.then(async () => {
      await mkdir(this.dir, { recursive: true });
      try { await copyFile(this.file, this.backup); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      const tmp = `${this.file}.${process.pid}.tmp`;
      await writeFile(tmp, JSON.stringify(this.data, null, 2), { mode: 0o600 });
      await rename(tmp, this.file);
    });
    return this.queue;
  }
}
