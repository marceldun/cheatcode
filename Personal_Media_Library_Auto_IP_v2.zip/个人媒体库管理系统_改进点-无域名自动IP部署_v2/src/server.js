import express from 'express';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile, mkdir, unlink } from 'node:fs/promises';
import { Store } from './store.js';
import { findCover, cacheCover } from './cover.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const dataDir = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
const port = Number(process.env.PORT || 3000);
const initialPassword = process.env.ADMIN_PASSWORD;
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const secureCookie = process.env.COOKIE_SECURE === 'true';
const store = new Store(dataDir);

function b64(x) { return Buffer.from(x).toString('base64url'); }
function sign(payload) { return `${b64(payload)}.${crypto.createHmac('sha256', sessionSecret).update(b64(payload)).digest('base64url')}`; }
function verify(token) {
  if (!token) return false; const [body, sig] = token.split('.'); if (!body || !sig) return false;
  const expected = crypto.createHmac('sha256', sessionSecret).update(body).digest();
  let actual; try { actual = Buffer.from(sig, 'base64url'); } catch { return false; }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return false;
  try { return JSON.parse(Buffer.from(body, 'base64url')).exp > Date.now(); } catch { return false; }
}
function cookies(req) { return Object.fromEntries((req.headers.cookie || '').split(';').filter(Boolean).map(x => { const i=x.indexOf('='); return [decodeURIComponent(x.slice(0,i).trim()), decodeURIComponent(x.slice(i+1))]; })); }
function hashPassword(password, salt = crypto.randomBytes(16)) { return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (e, key) => e ? reject(e) : resolve(`${salt.toString('hex')}:${key.toString('hex')}`))); }
async function checkPassword(password, saved) { const [saltHex, hashHex] = saved.split(':'); const candidate = await hashPassword(password, Buffer.from(saltHex, 'hex')); return crypto.timingSafeEqual(Buffer.from(candidate.split(':')[1], 'hex'), Buffer.from(hashHex, 'hex')); }

const settingsFile = path.join(dataDir, 'settings.json');
let passwordHash;
async function initSettings() {
  await mkdir(dataDir, { recursive: true });
  try { passwordHash = JSON.parse(await readFile(settingsFile, 'utf8')).passwordHash; }
  catch (e) { if (e.code !== 'ENOENT') throw e; if (!initialPassword || initialPassword.length < 10) throw new Error('首次启动必须提供至少10位的ADMIN_PASSWORD'); passwordHash = await hashPassword(initialPassword); await writeFile(settingsFile, JSON.stringify({ passwordHash }, null, 2), { mode: 0o600 }); }
}

const app = express(); app.disable('x-powered-by'); app.use(express.json({ limit: '64kb' }));
app.use((req,res,next) => { res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'");next(); });
const attempts = new Map();
app.get('/api/health', (req,res) => res.json({ ok:true, items:store.data.items.length }));
app.post('/api/login', async (req,res) => {
  const ip=req.ip, now=Date.now(), entry=attempts.get(ip)||{count:0,until:0}; if(entry.until>now) return res.status(429).json({error:'尝试次数过多，请15分钟后重试'});
  if(typeof req.body?.password!=='string' || !(await checkPassword(req.body.password,passwordHash))){ entry.count++;if(entry.count>=8){entry.until=now+900000;entry.count=0;}attempts.set(ip,entry);return res.status(401).json({error:'密码错误'}); }
  attempts.delete(ip);const token=sign(JSON.stringify({exp:Date.now()+30*86400000}));res.setHeader('Set-Cookie',`library_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${secureCookie?'; Secure':''}`);res.json({ok:true});
});
app.post('/api/logout',(req,res)=>{res.setHeader('Set-Cookie',`library_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secureCookie?'; Secure':''}`);res.json({ok:true});});
function auth(req,res,next){if(!verify(cookies(req).library_session))return res.status(401).json({error:'请先登录'});next();}
app.get('/api/me',auth,(req,res)=>res.json({authenticated:true}));
app.get('/api/items',auth,(req,res)=>res.json(store.list()));
function input(body){const title=String(body.title||'').trim().slice(0,160),description=String(body.description||'').trim().slice(0,2000),status=body.status==='completed'?'completed':'active';if(!title)throw new Error('请输入标题');return{title,description,status};}
async function updateCover(item){if(process.env.COVER_SEARCH_DISABLED==='true')return store.update(item.id,{cover:null,coverSource:null,coverUpdatedAt:new Date().toISOString()});const candidate=await findCover(item.title);if(!candidate)return store.update(item.id,{cover:null,coverSource:null,coverUpdatedAt:new Date().toISOString()});const cover=await cacheCover(candidate,item.id,path.join(dataDir,'covers'));return store.update(item.id,{cover,coverSource:candidate.page,coverUpdatedAt:new Date().toISOString()});}
app.post('/api/items',auth,async(req,res)=>{try{const item=await store.create(input(req.body));let result=item;try{result=await updateCover(item);}catch(e){console.error(e.message);}res.status(201).json(result);}catch(e){res.status(400).json({error:e.message});}});
app.put('/api/items/:id',auth,async(req,res)=>{try{const old=store.get(req.params.id);if(!old)return res.status(404).json({error:'记录不存在'});const values=input(req.body),changed=old.title!==values.title;let item=await store.update(old.id,values);if(changed){try{item=await updateCover(item);}catch(e){console.error(e.message);}}res.json(item);}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/items/:id/refresh-cover',auth,async(req,res)=>{const item=store.get(req.params.id);if(!item)return res.status(404).json({error:'记录不存在'});try{res.json(await updateCover(item));}catch(e){res.status(502).json({error:e.message});}});
app.delete('/api/items/:id',auth,async(req,res)=>{const item=await store.remove(req.params.id);if(!item)return res.status(404).json({error:'记录不存在'});if(item.cover?.startsWith('/covers/'))unlink(path.join(dataDir,item.cover)).catch(()=>{});res.json({ok:true});});
app.use('/covers',auth,express.static(path.join(dataDir,'covers'),{fallthrough:false,maxAge:'7d'}));
app.use(express.static(path.join(root,'public'),{extensions:['html']}));
app.use((req,res)=>res.sendFile(path.join(root,'public/index.html')));

await store.init();await initSettings();
const server=app.listen(port,'0.0.0.0',()=>console.log(`Library Manager listening on :${port}`));
const retryMissing=async()=>{for(const item of store.list().filter(x=>!x.cover)){try{await updateCover(item);}catch{}}};setTimeout(retryMissing,5000);setInterval(retryMissing,24*3600*1000).unref();
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>process.exit(0)));
export { app, server };
