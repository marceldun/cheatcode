import { mkdir, writeFile, rename } from 'node:fs/promises';
import path from 'node:path';

const UA = 'PersonalMediaLibrary/1.0 (private self-hosted library)';
const timeout = ms => AbortSignal.timeout(ms);

function normalize(s = '') { return s.normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, ''); }
function score(query, title) {
  const q = normalize(query), t = normalize(title);
  if (!q || !t) return 0;
  if (q === t) return 100;
  if (t.includes(q) || q.includes(t)) return 70 - Math.abs(t.length - q.length);
  let common = 0; for (const c of new Set(q)) if (t.includes(c)) common++;
  return common / Math.max(new Set(q).size, 1) * 30;
}

async function wikipediaCandidates(title, lang, fetchImpl) {
  const params = new URLSearchParams({ action: 'query', format: 'json', origin: '*', generator: 'search', gsrsearch: title, gsrlimit: '8', prop: 'pageimages|info', inprop: 'url', piprop: 'thumbnail', pithumbsize: '800' });
  const res = await fetchImpl(`https://${lang}.wikipedia.org/w/api.php?${params}`, { headers: { 'User-Agent': UA }, signal: timeout(8000) });
  if (!res.ok) return [];
  const data = await res.json();
  return Object.values(data.query?.pages || {}).filter(p => p.thumbnail?.source).map(p => ({ title: p.title, image: p.thumbnail.source, page: p.fullurl, provider: `${lang}.wikipedia.org`, score: score(title, p.title) }));
}

async function anilistCandidate(title, fetchImpl) {
  const query = `query($search:String){Media(search:$search,type:ANIME){title{romaji english native} coverImage{extraLarge large} siteUrl}}`;
  const res = await fetchImpl('https://graphql.anilist.co', { method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': UA }, body: JSON.stringify({ query, variables: { search: title } }), signal: timeout(8000) });
  if (!res.ok) return [];
  const m = (await res.json()).data?.Media; if (!m?.coverImage) return [];
  const names = [m.title?.native, m.title?.english, m.title?.romaji].filter(Boolean);
  return [{ title: names[0], image: m.coverImage.extraLarge || m.coverImage.large, page: m.siteUrl, provider: 'anilist.co', score: Math.max(...names.map(n => score(title, n))) + 5 }];
}

async function jikanCandidates(title, fetchImpl) {
  const res = await fetchImpl(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=5`, { headers: { 'User-Agent': UA }, signal: timeout(8000) });
  if (!res.ok) return []; const data = await res.json();
  return (data.data || []).filter(x => x.images?.jpg?.large_image_url).map(x => { const names=[x.title,x.title_english,x.title_japanese].filter(Boolean); return { title:names[0], image:x.images.jpg.large_image_url, page:x.url, provider:'api.jikan.moe', score:Math.max(...names.map(n=>score(title,n)))+4 }; });
}
async function tvmazeCandidates(title, fetchImpl) {
  const res = await fetchImpl(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(title)}`, { headers: { 'User-Agent': UA }, signal: timeout(8000) });
  if (!res.ok) return []; const data = await res.json();
  return data.filter(x=>x.show?.image).slice(0,5).map(x=>({title:x.show.name,image:x.show.image.original||x.show.image.medium,page:x.show.url,provider:'api.tvmaze.com',score:score(title,x.show.name)+2}));
}
async function openLibraryCandidates(title, fetchImpl) {
  const res = await fetchImpl(`https://openlibrary.org/search.json?title=${encodeURIComponent(title)}&limit=5&fields=key,title,cover_i`, { headers: { 'User-Agent': UA }, signal: timeout(8000) });
  if (!res.ok) return []; const data = await res.json();
  return (data.docs||[]).filter(x=>x.cover_i).map(x=>({title:x.title,image:`https://covers.openlibrary.org/b/id/${x.cover_i}-L.jpg`,page:`https://openlibrary.org${x.key}`,provider:'openlibrary.org',score:score(title,x.title)}));
}
async function steamCandidates(title, fetchImpl) {
  const res = await fetchImpl(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(title)}&l=english&cc=US`, { headers: { 'User-Agent': UA }, signal: timeout(8000) });
  if (!res.ok) return []; const data = await res.json();
  return (data.items||[]).slice(0,5).map(x=>({title:x.name,image:x.tiny_image,page:`https://store.steampowered.com/app/${x.id}`,provider:'store.steampowered.com',score:score(title,x.name)+3}));
}

export async function findCover(title, fetchImpl = fetch) {
  const results = await Promise.allSettled([wikipediaCandidates(title, 'zh', fetchImpl), wikipediaCandidates(title, 'en', fetchImpl), anilistCandidate(title, fetchImpl), jikanCandidates(title, fetchImpl), tvmazeCandidates(title, fetchImpl), openLibraryCandidates(title, fetchImpl), steamCandidates(title, fetchImpl)]);
  const candidates = results.flatMap(r => r.status === 'fulfilled' ? r.value : []);
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0] || null;
}

function extension(contentType, bytes) {
  if (contentType.includes('png') || bytes[0] === 0x89 && bytes[1] === 0x50) return 'png';
  if (contentType.includes('webp') || String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP') return 'webp';
  return 'jpg';
}

export async function cacheCover(candidate, id, coverDir, fetchImpl = fetch) {
  if (!candidate?.image) return null;
  const res = await fetchImpl(candidate.image, { headers: { 'User-Agent': UA }, signal: timeout(12000) });
  if (!res.ok) throw new Error(`图片下载失败: HTTP ${res.status}`);
  const type = res.headers.get('content-type') || '';
  if (!type.startsWith('image/')) throw new Error('封面地址返回的不是图片');
  const buffer = Buffer.from(await res.arrayBuffer());
  if (buffer.length < 100 || buffer.length > 10 * 1024 * 1024) throw new Error('封面图片大小异常');
  const ext = extension(type, buffer); await mkdir(coverDir, { recursive: true });
  const filename = `${id}.${ext}`, tmp = path.join(coverDir, `${filename}.tmp`);
  await writeFile(tmp, buffer); await rename(tmp, path.join(coverDir, filename));
  return `/covers/${filename}`;
}

export { score };
