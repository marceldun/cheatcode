个人媒体库管理系统 v9
改进点：放弃Gemini，改用Google Images官方接口；补全后台需求清单

封面流程：标题与分类 → Google Programmable Search图片搜索 → 相关性、排名、竖版比例评分 → VPS下载 → 本地缓存 → 网站展示。
旧Gemini密钥和旧Gemini封面缓存不会作为v9新封面来源。

首次配置需要：
1. Google Custom Search JSON API Key。
2. 已启用图片搜索的Programmable Search Engine ID（cx）。
安装器会真实搜索一张图片验证两项配置，失败立即显示Google原始错误。

速度说明：保存后本地即时封面实测0.0018秒出现；同名Google封面命中缓存时可立即替换。首次真实Google图片需要经过公网搜索和图片下载，无法控制Google及图片源的网络延迟，所以不虚假承诺每次真实图片都在1秒内完成；页面不会等待，会在后台自动替换。

管理员用户名：admin。网站后台、会员、收藏、皮肤、字体等v7-v8功能全部保留。
完整后台优化方向见《后台管理系统完整需求与优化方向.txt》。
