# WhatsApp官方Cloud API + 本地开源AI服装外贸业务员

版本：**改进点—永久免费AI v4**。v3及更早版本均保留，未覆盖或删除。

## 适用配置

- Windows 10/11，内存16GB或更多。
- 电脑需要在接待客户期间保持开机联网。
- 默认本地模型：`qwen3-vl:8b`，支持多语言文字和服装参考图片。

## 最少操作

双击 `一键安装部署_Windows.bat`。程序自动安装 Node.js、Ollama、本地模型和依赖，执行测试，部署免费Webhook，生成安全令牌并设置开机自启。

账号本人仍必须完成两项官方安全授权：

1. 在浏览器同意Cloudflare登录。
2. 提供Meta长期令牌、App Secret和Phone Number ID，并在Meta应用页面粘贴脚本生成的Webhook地址和验证字符串。

这些步骤用于证明Cloudflare账号和WhatsApp号码属于你，任何软件都不能合法代点。

Meta三项值的位置：`App settings → Basic` 中复制 App Secret；`WhatsApp → API Setup` 中复制 Phone Number ID；`Business settings → System users → Generate token` 生成包含 `whatsapp_business_messaging` 与 `whatsapp_business_management` 权限的长期令牌。安装器会在需要时自动打开Meta应用后台。

## 费用边界

- 本地开源模型不按消息收费，不需要OpenAI API或其他收费AI平台。
- Cloudflare免费额度足够普通小型外贸客服流量。
- 系统只处理客户主动发起后的会话，不创建或发送超过24小时窗口的付费模板消息。
- 已有电脑、网络和用电属于运行条件。Meta或Cloudflare未来若调整政策，任何软件都无法保证第三方服务永久维持当前免费规则。

## 工作方式

Meta把客户消息发送到Cloudflare Worker；Worker完成官方签名验证、去重和排队。本地电脑每两秒安全取一次消息，调用Ollama本地模型生成回复，再通过官方Cloud API发送。电脑不开放公网端口。

AI会按客户语言回复，收集产品、面料克重、数量、颜色尺码、定制工艺、标签包装、目的国、贸易条款、样品和交期。它不会编造价格、MOQ、认证、库存、运费或交期。

