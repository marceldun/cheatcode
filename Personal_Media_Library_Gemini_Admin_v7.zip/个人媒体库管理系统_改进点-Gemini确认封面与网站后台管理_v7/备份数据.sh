#!/usr/bin/env bash
set -e;mkdir -p /opt/personal-media-library/backups;n="library-$(date +%Y%m%d-%H%M%S).tar.gz";tar czf "/opt/personal-media-library/backups/$n" -C /var/lib/personal-media-library .;echo "/opt/personal-media-library/backups/$n"
